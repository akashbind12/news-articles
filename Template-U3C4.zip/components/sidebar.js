function sidebar() {


    // return your html component here
    //Make sure to give input search box id as ""
    return  `<div>Login</div>
    <input id="searchbar" type="text">
    <div>Startup</div>
    <div>Newsletters</div>
    <div>Audio</div>
    <div>Video</div>`;
   
}
export default sidebar;